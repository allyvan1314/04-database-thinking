create
    definer = admin@localhost procedure GET_USR_INFOR(IN usrName varchar(20), OUT alName varchar(40),
                                                      OUT alEmail varchar(30), OUT alPhone varchar(11),
                                                      OUT alStt varchar(20))
BEGIN
	SELECT AL_NAME INTO alName FROM AL_USER WHERE AL_USERNAME = usrName;
    SELECT AL_EMAIL INTO alEmail FROM AL_USER WHERE AL_USERNAME = usrName;
    SELECT AL_PHONE INTO alPhone FROM AL_USER WHERE AL_USERNAME = usrName;
    SELECT AL_STATUS INTO alStt FROM AL_USER WHERE AL_USERNAME = usrName;
    SELECT alName, alEmail, alPhone, alStt;
END;

