create
    definer = admin@localhost procedure UPDATE_FRRQ(IN usrFrom varchar(20), IN usrTo varchar(20), IN stt varchar(20))
begin
	DECLARE FromId INT DEFAULT 0;
    DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO FromId FROM AL_USER WHERE AL_USERNAME = usrFrom;
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrTo;
    
	UPDATE AL_FR_REQUEST
    SET AL_STATUS = stt
    WHERE AL_FROM = FromId AND AL_TO = ToId;
end;

