create
    definer = admin@localhost procedure CREATE_ACC(IN usrName varchar(20), IN pass varchar(20), IN if_name varchar(30),
                                                   IN email varchar(40), IN phone varchar(11), IN stt varchar(15))
BEGIN
	INSERT INTO AL_USER (AL_USERNAME, AL_PASSWORD, AL_NAME, AL_EMAIL, AL_PHONE, AL_STATUS) VALUES (usrName, pass, if_name, email, phone, stt);
END;

