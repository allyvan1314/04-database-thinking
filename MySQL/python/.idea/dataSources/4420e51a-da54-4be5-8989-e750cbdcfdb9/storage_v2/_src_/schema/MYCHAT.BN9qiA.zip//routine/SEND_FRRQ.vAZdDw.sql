create
    definer = admin@localhost procedure SEND_FRRQ(IN usrFrom varchar(20), IN usrTo varchar(20), IN mes varchar(100))
BEGIN
	DECLARE FromId INT DEFAULT 0;
    DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO FromId FROM AL_USER WHERE AL_USERNAME = usrFrom;
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrTo;
    
	INSERT INTO AL_FR_REQUEST (AL_FROM, AL_TO, AL_CONTENT, AL_DATE_CREATE, AL_STATUS)
					   VALUES (FromId , ToId , mes       , NOW()     , 'waiting');
END;

