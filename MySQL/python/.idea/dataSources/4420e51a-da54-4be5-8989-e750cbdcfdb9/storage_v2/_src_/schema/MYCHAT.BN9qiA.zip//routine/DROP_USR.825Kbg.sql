create
    definer = admin@localhost procedure DROP_USR(IN usrName varchar(20))
BEGIN
	DELETE FROM AL_USER WHERE AL_USERNAME = usrName;
END;

