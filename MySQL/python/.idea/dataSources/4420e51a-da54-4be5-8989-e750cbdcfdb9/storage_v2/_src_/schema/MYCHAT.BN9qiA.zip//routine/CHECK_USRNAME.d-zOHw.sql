create
    definer = admin@localhost procedure CHECK_USRNAME(IN usrName varchar(20), OUT res int)
BEGIN
	IF EXISTS (SELECT * FROM AL_USER WHERE AL_USERNAME = usrName) THEN SET res = 1;
    ELSE SET res = 0;
    END IF;
END;

