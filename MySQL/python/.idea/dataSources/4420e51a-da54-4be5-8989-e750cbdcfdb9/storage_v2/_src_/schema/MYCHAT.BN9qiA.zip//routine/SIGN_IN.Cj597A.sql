create
    definer = admin@localhost procedure SIGN_IN(IN usrName varchar(20), IN pass varchar(20), OUT res int)
BEGIN
    IF EXISTS (SELECT * FROM AL_USER WHERE AL_USERNAME = usrName AND AL_PASSWORD = pass)
		THEN SET res = 1;
	ELSE SET RES = 0;
    END IF;
END;

