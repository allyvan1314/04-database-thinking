create
    definer = admin@localhost procedure CHECK_NEWMSG(IN usrName varchar(20), IN res int)
BEGIN
	DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrName;
    
    SELECT USR.AL_USERNAME, AL_CONTENT, AL_DATE
    FROM AL_MESS M, AL_USER USR
    WHERE AL_TO = ToId AND M.AL_STATUS = 'send' AND M.AL_TYPE = 'user'
    AND M.AL_FROM = USR.AL_USERID;
    
	UPDATE AL_MESS
    SET AL_STATUS = 'seen'
    WHERE AL_TO;
END;

