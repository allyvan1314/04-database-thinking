create
    definer = admin@localhost procedure SIGN_IN_WRAP(IN usrName varchar(20), IN pass varchar(20), OUT res int)
BEGIN
	CALL SIGN_IN(usrName, pass, res);
    SELECT res;
END;

