create
    definer = admin@localhost procedure CHECK_RELA(IN usrFrom varchar(20), IN usrTo varchar(20), OUT res int)
BEGIN
	DECLARE FromId INT DEFAULT 0;
    DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO FromId FROM AL_USER WHERE AL_USERNAME = usrFrom;
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrTo;
    
    IF EXISTS (SELECT * FROM AL_RELA WHERE (AL_USER1 = FromId AND AL_USER2 = ToId) OR (AL_USER1 = ToId AND AL_USER2 = FromId))
		THEN SET res = 1;
	ELSE SET res = 0;
    END IF;
    SELECT res;
END;

