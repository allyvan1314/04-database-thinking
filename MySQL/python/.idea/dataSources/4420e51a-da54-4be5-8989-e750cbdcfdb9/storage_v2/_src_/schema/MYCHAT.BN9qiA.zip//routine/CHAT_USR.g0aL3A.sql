create
    definer = admin@localhost procedure CHAT_USR(IN usrFrom varchar(20), IN usrTo varchar(20), IN mess varchar(1000))
begin
	DECLARE FromId INT DEFAULT 0;
    DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO FromId FROM AL_USER WHERE AL_USERNAME = usrFrom;
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrTo;
    
	INSERT INTO AL_MESS (AL_FROM, AL_TO, AL_CONTENT, AL_DATE, AL_STATUS, AL_TYPE)
    VALUES (FromId, ToId, mess, NOW(), 'send', 'user');
end;

