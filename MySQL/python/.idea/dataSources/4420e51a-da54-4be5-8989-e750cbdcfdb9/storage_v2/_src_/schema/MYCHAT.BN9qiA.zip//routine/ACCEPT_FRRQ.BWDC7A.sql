create
    definer = admin@localhost procedure ACCEPT_FRRQ(IN usrFrom varchar(20), IN usrTo varchar(20))
BEGIN
	DECLARE FromId INT DEFAULT 0;
    DECLARE ToId INT DEFAULT 0;
    
    SELECT AL_USERID INTO FromId FROM AL_USER WHERE AL_USERNAME = usrFrom;
    SELECT AL_USERID INTO ToId FROM AL_USER WHERE AL_USERNAME = usrTo;
    
    INSERT INTO AL_RELA (AL_USER1, AL_USER2, AL_RELA) VALUES (FromId, ToId, 'friend');
END;

