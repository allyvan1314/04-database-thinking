create
    definer = admin@localhost procedure CHECK_USRNAME_WRAP(IN usrName varchar(20), OUT res int)
BEGIN
	CALL CHECK_USRNAME(usrName, res);
    SELECT res;
END;

