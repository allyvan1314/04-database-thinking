create
    definer = admin@localhost procedure UPDATE_STT(IN usrName varchar(20), IN stt varchar(15))
BEGIN
	UPDATE AL_USER SET AL_STATUS = stt WHERE AL_USERNAME = usrName;
END;

